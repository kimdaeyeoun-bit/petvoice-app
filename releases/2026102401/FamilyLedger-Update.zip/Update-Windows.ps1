﻿param([string]$InstallPath = '')
$ErrorActionPreference = 'Stop'
$payload = Join-Path $PSScriptRoot 'Payload'
if (-not (Test-Path (Join-Path $payload 'server.cjs'))) { throw 'Payload folder is missing. Extract the complete update ZIP first.' }
if (-not $InstallPath) {
    $candidates=@((Join-Path $env:USERPROFILE 'FamilyLedger'),(Join-Path $env:LOCALAPPDATA 'FamilyLedger')) | Where-Object { Test-Path (Join-Path $_ 'data\ledger.sqlite') }
    if (@($candidates).Count -eq 1) { $InstallPath=@($candidates)[0] } else { throw 'Specify the existing install folder' }
}
$InstallPath = (Resolve-Path -LiteralPath $InstallPath).Path.TrimEnd('\')
if (-not (Test-Path (Join-Path $InstallPath 'server.cjs'))) { throw 'This is not the existing application folder. Nothing was changed.' }
if ((Get-Content (Join-Path $InstallPath 'package.json') -Raw | ConvertFrom-Json).name -ne 'family-ledger') { throw 'Unknown application. Nothing changed.' }
$dbPath = Join-Path $InstallPath 'data\ledger.sqlite'
if (-not (Test-Path $dbPath)) { throw 'Existing data\ledger.sqlite was not found. Stopped to avoid creating a new empty database. Locate the actual installation first. Other database formats need a separate migration.' }
$node = Get-Command node -ErrorAction Stop
$version = & $node.Source -p 'process.versions.node'
if ($LASTEXITCODE -ne 0 -or $version -notmatch '^24\.') { throw 'Node.js 24 is required.' }
$client = New-Object Net.Sockets.TcpClient
try {
    $attempt = $client.BeginConnect('127.0.0.1',3210,$null,$null)
    if ($attempt.AsyncWaitHandle.WaitOne(500) -and $client.Connected) { throw 'Stop the existing server with Ctrl+C before updating. No process will be killed automatically.' }
} finally { $client.Close() }
# An exclusive open also catches the normal Windows SQLite file-sharing case.
$exclusive = [IO.File]::Open($dbPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
$exclusive.Close()
# Verify the payload before executing it. The manifest is also useful for detecting transfer corruption.
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'payload-sha256.json') -Raw | ConvertFrom-Json
foreach ($record in $manifest) {
    $file = Join-Path $payload $record.path
    if (-not (Test-Path -LiteralPath $file) -or (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256) { throw ('Payload checksum mismatch: ' + $record.path) }
}
& $node.Source (Join-Path $payload 'validate-db.cjs') $dbPath
if ($LASTEXITCODE -ne 0) { throw 'Existing database validation failed. Original files unchanged.' }
$stamp = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,6)
$parent = Split-Path -Parent $InstallPath
$leaf = Split-Path -Leaf $InstallPath
$backup = Join-Path $parent ($leaf + '-backup-' + $stamp)
$stage = Join-Path $parent ($leaf + '-staged-' + $stamp)
$previous = Join-Path $parent ($leaf + '-previous-' + $stamp)
New-Item -ItemType Directory -Path $backup | Out-Null
Get-ChildItem -LiteralPath $InstallPath -Force | Copy-Item -Destination $backup -Recurse -Force
$originalFiles = @(Get-ChildItem -LiteralPath $InstallPath -File -Recurse -Force)
foreach ($file in $originalFiles) {
    $relative = $file.FullName.Substring($InstallPath.Length + 1)
    $copy = Join-Path $backup $relative
    if (-not (Test-Path -LiteralPath $copy) -or (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $copy -Algorithm SHA256).Hash) { throw ('Backup verification failed. Original untouched: ' + $relative) }
}
if (@(Get-ChildItem -LiteralPath $backup -File -Recurse -Force).Count -ne $originalFiles.Count) { throw 'Backup file count mismatch. Original untouched.' }
Write-Host "Verified complete backup: $backup"
New-Item -ItemType Directory -Path $stage | Out-Null
Get-ChildItem -LiteralPath $backup -Force | Copy-Item -Destination $stage -Recurse -Force
# The payload does NOT contain data, config.json, private keys, or credentials.
foreach ($item in Get-ChildItem -LiteralPath $payload -Force) {
    if ($item.Name -in @('data','config.json','.env','push-keys.json')) { throw 'Protected path found in payload. Original untouched.' }
    Copy-Item -LiteralPath $item.FullName -Destination $stage -Recurse -Force
}
foreach ($record in $manifest) {
    if ((Get-FileHash -LiteralPath (Join-Path $stage $record.path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256) { throw ('Staged payload verification failed: ' + $record.path) }
}
if ((Get-FileHash -LiteralPath $dbPath -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath (Join-Path $stage 'data\ledger.sqlite') -Algorithm SHA256).Hash) { throw 'Staged database differs. Original untouched.' }
$originalConfig = Join-Path $InstallPath 'config.json'
if ((Test-Path $originalConfig) -and ((Get-FileHash -LiteralPath $originalConfig).Hash -ne (Get-FileHash -LiteralPath (Join-Path $stage 'config.json')).Hash)) { throw 'Staged configuration differs. Original untouched.' }
# Both test runners explicitly create and remove separate OS-temp databases.
& $node.Source (Join-Path $stage 'test.cjs')
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed. Original installation untouched.' }
& $node.Source (Join-Path $stage 'test-v2.cjs')
if ($LASTEXITCODE -ne 0) { throw 'Upgrade tests failed. Original installation untouched.' }
& $node.Source (Join-Path $stage 'test-sms.cjs')
if ($LASTEXITCODE -ne 0) { throw 'SMS test failed. Original unchanged.' }
# Refuse activation if another process changed the original while the update was prepared.
foreach ($file in $originalFiles) {
    $relative = $file.FullName.Substring($InstallPath.Length + 1)
    if ((Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath (Join-Path $backup $relative) -Algorithm SHA256).Hash) { throw 'Original files changed during update. Activation stopped; original is still in place.' }
}
if (@(Get-ChildItem -LiteralPath $InstallPath -File -Recurse -Force).Count -ne $originalFiles.Count) { throw 'Original file list changed during update. Original is still in place.' }
Move-Item -LiteralPath $InstallPath -Destination $previous
try { Move-Item -LiteralPath $stage -Destination $InstallPath }
catch {
    Move-Item -LiteralPath $previous -Destination $InstallPath
    throw 'Activation failed. Previous installation was restored.'
}
Write-Host "Updated existing installation: $InstallPath"
Write-Host "Previous complete installation retained: $previous"
Write-Host 'Start the existing Start-Windows.cmd shortcut. Your existing HTTPS address stays the same.'
Write-Host 'The first startup makes an additional SQLite backup before additive schema migration.'
Write-Host 'Do not copy a migrated database back into an older app. To roll back, restore the complete pre-update folder.'
