﻿$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 must decode Tailscale's UTF-8 JSON as UTF-8.
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
Set-Location $PSScriptRoot
$node = Get-Command node -ErrorAction Stop
$version = & $node.Source -p 'process.versions.node'
if ($LASTEXITCODE -ne 0 -or $version -notmatch '^24\.') { throw 'Install Node.js 24 first: https://nodejs.org/' }
$tail = Get-Command tailscale -ErrorAction SilentlyContinue
if (-not $tail) {
    $exe = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
    if (-not (Test-Path $exe)) { throw 'Install Tailscale and sign in first: https://tailscale.com/download/windows' }
} else { $exe = $tail.Source }
$statusText = & $exe status --json
if ($LASTEXITCODE -ne 0) { throw 'Open Tailscale and sign in, then retry.' }
$status = ($statusText -join "`n") | ConvertFrom-Json
if ($status.BackendState -ne 'Running' -or -not $status.Self.DNSName) { throw 'Tailscale must be connected with MagicDNS enabled.' }
$dns = $status.Self.DNSName.TrimEnd('.')
$origin = "https://$dns"
$serveText = & $exe serve status --json
if ($LASTEXITCODE -ne 0) { throw 'Unable to inspect existing Tailscale Serve settings.' }
$serve = ($serveText -join "`n") | ConvertFrom-Json
if ($serve.Web -and @($serve.Web.PSObject.Properties).Count -gt 0) {
    $site = $serve.Web.PSObject.Properties[($dns + ':443')]
    $handler = if ($site) { $site.Value.Handlers.PSObject.Properties['/'] } else { $null }
    if (-not $handler -or $handler.Value.Proxy -ne 'http://127.0.0.1:3210' -or @($serve.Web.PSObject.Properties).Count -ne 1 -or @($site.Value.Handlers.PSObject.Properties).Count -ne 1) {
        throw 'Existing Tailscale Serve configuration found. Keep it unchanged; inspect tailscale serve status before configuring this app manually.'
    }
}
& $node.Source test.cjs
if ($LASTEXITCODE -ne 0) { throw 'App tests failed. Configuration was not changed.' }
& $exe serve --bg http://127.0.0.1:3210
if ($LASTEXITCODE -ne 0) { throw 'Serve setup failed. Follow the Tailscale HTTPS approval instructions printed above and retry.' }
$config = @{ publicOrigin = $origin } | ConvertTo-Json
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'config.json'), $config, (New-Object Text.UTF8Encoding($false)))
Write-Host "Family URL: $origin"
Write-Host 'Next: run Start-Windows.cmd. Keep the server window open.'
Write-Host 'All devices must be connected to the same authorized Tailscale network.'
Write-Host 'This script does not enable Tailscale Funnel or expose a public Internet port.'
