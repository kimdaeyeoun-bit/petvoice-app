'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const webpush=require('web-push');
const PEOPLE=['김대연','서정희'];
function seoul(now=new Date()){const p=Object.fromEntries(new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now).map(p=>[p.type,p.value]));return {day:`${p.year}-${p.month}-${p.day}`,hour:Number(p.hour)};}
function previous(day){return new Date(Date.parse(day+'T12:00:00Z')-86400000).toISOString().slice(0,10);}
function next(day){return new Date(Date.parse(day+'T12:00:00Z')+86400000).toISOString().slice(0,10);}
function parseNotification(raw,now=new Date()){
 const clean=raw.replace(/\s+/g,' ').trim(),tokens=[...clean.matchAll(/([0-9][0-9,]*)\s*원/g)];
 const amounts=tokens.filter(m=>!/(잔액|누적|한도|이용합계|총액|결제예정)\s*[:：]?\s*$/.test(clean.slice(Math.max(0,m.index-16),m.index)));
 const cancelled=/취소|승인거절|실패|거절|예정|인증번호|일회용|OTP/i.test(clean),date=/\b(20\d{2})[./-](\d{1,2})[./-](\d{1,2})\b/.exec(clean);
 const proposedDay=date?`${date[1]}-${date[2].padStart(2,'0')}-${date[3].padStart(2,'0')}`:seoul(now).day;
 const amount=amounts.length===1?Number(amounts[0][1].replaceAll(',','')):null;
 const kind=/이체|송금/.test(clean)?'transfer':/입금/.test(clean)?'income':'expense';
 return {day:proposedDay,kind,amount:Number.isSafeInteger(amount)&&amount>0&&amount<=1e12?amount:null,memo:clean.slice(0,500),needsReview:true,reason:cancelled?'취소·거절·예정·인증 관련 알림: 자동 등록하지 않음':amounts.length!==1?'거래 금액을 확정할 수 없음':date?'금액·날짜·계좌·거래 종류 확인 필요':'연도 포함 날짜 없음: 수신일 제안, 직접 확인 필요',blocked:cancelled};
}
function attach({db,dir,err,str,atomic,state,entry,putE,readBody,send,publicOrigin,local,sessions,auth,clock=()=>new Date(),pushTransport}){
 const all=(sql,...v)=>db.prepare(sql).all(...v),one=(sql,...v)=>db.prepare(sql).get(...v),run=(sql,...v)=>db.prepare(sql).run(...v);
 const version=db.prepare('PRAGMA user_version').get().user_version;
 if(version>2)throw Error('더 최신 DB입니다. 이전 프로그램으로 열 수 없습니다.');
 if(version<2){
  const backup=path.join(dir,'backups');fs.mkdirSync(backup,{recursive:true});
  db.prepare('VACUUM INTO ?').run(path.join(backup,'before-v2-'+Date.now()+'-'+crypto.randomUUID()+'.sqlite'));
  atomic(()=>db.exec(`
   CREATE TABLE IF NOT EXISTS entry_details(entry_id TEXT PRIMARY KEY REFERENCES entries(id) ON DELETE CASCADE,spent_by TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS request_keys(owner TEXT NOT NULL,key TEXT NOT NULL,hash TEXT NOT NULL,entry_id TEXT NOT NULL,PRIMARY KEY(owner,key));
   CREATE TABLE IF NOT EXISTS bridge_devices(id TEXT PRIMARY KEY,owner TEXT NOT NULL,name TEXT NOT NULL,token_hash TEXT UNIQUE NOT NULL,created TEXT NOT NULL,revoked INTEGER NOT NULL DEFAULT 0);
   CREATE TABLE IF NOT EXISTS captures(id TEXT PRIMARY KEY,owner TEXT NOT NULL,device_id TEXT NOT NULL,source TEXT NOT NULL,event_key TEXT NOT NULL,raw TEXT NOT NULL,suggestion TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',entry_id TEXT,created TEXT NOT NULL,UNIQUE(device_id,event_key));
   CREATE TABLE IF NOT EXISTS daily_reports(day TEXT PRIMARY KEY,payload TEXT NOT NULL,revision INTEGER NOT NULL,updated TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY,owner TEXT NOT NULL,day TEXT NOT NULL,seen INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL,UNIQUE(owner,day));
   CREATE TABLE IF NOT EXISTS push_subscriptions(endpoint TEXT PRIMARY KEY,owner TEXT NOT NULL,payload TEXT NOT NULL,last_error TEXT);
   PRAGMA user_version=2;
  `));
 }
 const keyFile=path.join(dir,'push-keys.json');
 let vapid;if(fs.existsSync(keyFile))vapid=JSON.parse(fs.readFileSync(keyFile,'utf8'));else{vapid=webpush.generateVAPIDKeys();fs.writeFileSync(keyFile,JSON.stringify(vapid),{mode:0o600,flag:'wx'});}
 const peers=new Set();let timer;
 function notify(type='changed'){for(const p of peers){if(!sessions.has(p.user.id)||p.user.until<=Date.now()){p.res.end();peers.delete(p);}else p.res.write(`event: ${type}\ndata: {}\n\n`);}}
 function details(){return Object.fromEntries(all('SELECT * FROM entry_details').map(d=>[d.entry_id,d.spent_by]));}
 function addDetails(e,spentBy){if(![...PEOPLE,'공동'].includes(spentBy))err('지출 귀속자는 가족 또는 공동을 선택하세요.');run('INSERT INTO entry_details VALUES(?,?)',e.id,spentBy);}
 function payer(e,map,dd){return dd[e.id]||([ ...PEOPLE].includes(map[e.src||e.dst]?.owner)?map[e.src||e.dst].owner:e.actor);}
 function duplicate(e){const matches=all('SELECT * FROM entries WHERE day=? AND amount=? AND kind=? AND src IS ? AND dst IS ? ORDER BY created DESC LIMIT 20',e.day,e.amount,e.kind,e.src,e.dst);return matches.map(x=>({id:x.id,day:x.day,amount:x.amount,memo:x.memo,actor:x.actor,confidence:x.memo.replace(/\s/g,'')===e.memo.replace(/\s/g,'')?'exact':'possible'}));}
 function report(day){
  const s=state(),map=Object.fromEntries(s.accounts.map(a=>[a.id,a])),dd=details();
  const before=Object.fromEntries(s.accounts.map(a=>[a.id,a.opening])),after={...before};
  const people=Object.fromEntries([...PEOPLE,'공동'].map(n=>[n,{income:0,expense:0}]));let income=0,expense=0,transfers=0;
  for(const e of s.entries){if(e.day<day){if(e.src)before[e.src]-=e.amount;if(e.dst)before[e.dst]+=e.amount;}if(e.day<=day){if(e.src)after[e.src]-=e.amount;if(e.dst)after[e.dst]+=e.amount;}if(e.day!==day)continue;const n=payer(e,map,dd);if(e.kind==='income'){income+=e.amount;people[n].income+=e.amount;}else if(e.kind==='expense'){expense+=e.amount;people[n].expense+=e.amount;}else transfers++;}
  const sum=b=>Object.values(b).reduce((a,v)=>a+v,0),assets=Object.values(after).filter(v=>v>0).reduce((a,v)=>a+v,0),liabilities=-Object.values(after).filter(v=>v<0).reduce((a,v)=>a+v,0);
  const result={day,timeZone:'Asia/Seoul',closeTime:'22:00',people,income,expense,netChange:sum(after)-sum(before),openingNet:sum(before),closingNet:sum(after),assets,liabilities,balances:after,transferCount:transfers,entryCount:s.entries.filter(e=>e.day===day).length};
  if(!Object.values(result).filter(v=>typeof v==='number').every(Number.isSafeInteger))err('결산 금액 범위 초과');return result;
 }
 async function push(owner,day){for(const sub of all('SELECT * FROM push_subscriptions WHERE owner=?',owner)){try{
   const payload=JSON.stringify({title:'철인가족 일일 결산',body:`${day} 결산 보고서가 도착했습니다.`,url:'/?report='+day,tag:'report-'+day});
   const options={TTL:86400,vapidDetails:{subject:publicOrigin.startsWith('https://')?publicOrigin:'mailto:family-ledger@example.invalid',publicKey:vapid.publicKey,privateKey:vapid.privateKey}};
   if(pushTransport)await pushTransport(JSON.parse(sub.payload),payload,options);else await webpush.sendNotification(JSON.parse(sub.payload),payload,options);
   run('UPDATE push_subscriptions SET last_error=NULL WHERE endpoint=?',sub.endpoint);
  }catch(e){if([404,410].includes(e.statusCode))run('DELETE FROM push_subscriptions WHERE endpoint=?',sub.endpoint);else run('UPDATE push_subscriptions SET last_error=? WHERE endpoint=?','전송 실패: '+(e.statusCode||'network'),sub.endpoint);}}
 }
 function saveReport(day,createNotice=false,sendPush=true){const value=report(day),payload=JSON.stringify(value),old=one('SELECT * FROM daily_reports WHERE day=?',day);if(old?.payload===payload)return false;
  atomic(()=>{run('INSERT INTO daily_reports VALUES(?,?,?,?) ON CONFLICT(day) DO UPDATE SET payload=excluded.payload,revision=excluded.revision,updated=excluded.updated',day,payload,(old?.revision||0)+1,clock().toISOString());
   if(createNotice)for(const owner of PEOPLE){const n=run('INSERT OR IGNORE INTO notifications VALUES(?,?,?,0,?)',crypto.randomUUID(),owner,day,clock().toISOString());if(n.changes&&sendPush)queueMicrotask(()=>push(owner,day).catch(()=>{}));}
  });return true;
 }
 function scheduler(now=clock()){if(all('SELECT name FROM users').length!==2)return;
  const t=seoul(now),cutoff=t.hour>=22?t.day:previous(t.day),days=new Set(all('SELECT DISTINCT day FROM entries WHERE day<=?',cutoff).map(r=>r.day));days.add(cutoff);
  const last=one('SELECT MAX(day) AS day FROM daily_reports')?.day;
  if(last){for(let d=next(last);d<=cutoff;d=next(d)){days.add(d);if(days.size>40000)throw Error('결산 기간 범위 초과');}}
  let changed=false;for(const day of [...days].sort())if(!one('SELECT day FROM daily_reports WHERE day=?',day))changed=saveReport(day,true,day===cutoff)||changed;
  if(changed)notify('reports');
 }
 function changed(){for(const r of all('SELECT day FROM daily_reports'))saveReport(r.day,false);scheduler();notify();}
 function captureUser(req){const token=/^Bearer ([a-f0-9]{64})$/.exec(req.headers.authorization||'')?.[1];if(!token)err('수집 기기 인증 필요',401);const hash=crypto.createHash('sha256').update(token).digest('hex'),d=one('SELECT * FROM bridge_devices WHERE token_hash=? AND revoked=0',hash);if(!d)err('수집 기기 인증 만료 또는 해제',401);return d;}
 async function collect(req,res){const d=captureUser(req),b=await readBody(req),source=str(b.source,200),eventKey=str(b.eventKey,200),raw=str(b.text,4000);if(!source||!eventKey||!raw.trim())err('알림 출처와 본문이 필요합니다.');
 if(/인증번호|인증\s*코드|일회용|OTP|비밀번호/i.test(raw))return send(res,200,{ignored:true,reason:'인증·비밀번호 관련 알림은 보관하지 않습니다.'});
 const prior=one('SELECT id,status FROM captures WHERE device_id=? AND event_key=?',d.id,eventKey);if(prior)return send(res,200,{...prior,reused:true});
 if(one("SELECT COUNT(*) AS n FROM captures WHERE device_id=? AND created>?",d.id,new Date(clock().getTime()-60000).toISOString()).n>=60)err('수집 요청 한도 초과',429);
 let received=clock();if(b.receivedAt!==undefined){if(typeof b.receivedAt!=='string'||!Number.isFinite(Date.parse(b.receivedAt))||Date.parse(b.receivedAt)>clock().getTime()+300000||Date.parse(b.receivedAt)<Date.parse('2000-01-01T00:00:00Z'))err('알림 수신 시각 오류');received=new Date(b.receivedAt);}const id=crypto.randomUUID(),suggestion={...parseNotification(raw,received),receivedAt:received.toISOString()};run('INSERT INTO captures(id,owner,device_id,source,event_key,raw,suggestion,created) VALUES(?,?,?,?,?,?,?,?)',id,d.owner,d.id,source,eventKey,raw,JSON.stringify(suggestion),clock().toISOString());notify('captures');return send(res,200,{id,status:'pending',suggestion});
 }
 async function handle(key,req,res,u,url){
  if(key==='GET /api/events'){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-store','Connection':'keep-alive','X-Accel-Buffering':'no'});const peer={res,user:u};peers.add(peer);res.write('event: ready\ndata: {}\n\n');req.on('close',()=>peers.delete(peer));return true;}
  if(key==='GET /api/reports'){scheduler();return send(res,200,{reports:all('SELECT * FROM daily_reports ORDER BY day DESC LIMIT 120').map(r=>({...JSON.parse(r.payload),revision:r.revision,updated:r.updated})),today:report(seoul(clock()).day),notifications:all('SELECT * FROM notifications WHERE owner=? ORDER BY day DESC LIMIT 120',u.name)}),true;}
  if(key==='POST /api/reports/seen'){const b=await readBody(req);run('UPDATE notifications SET seen=1 WHERE owner=? AND id=?',u.name,str(b.id,100));return send(res,200,{ok:true}),true;}
  if(key==='GET /api/push/key')return send(res,200,{publicKey:vapid.publicKey,subscriptions:all('SELECT endpoint,last_error FROM push_subscriptions WHERE owner=?',u.name)}),true;
  if(key==='POST /api/push/subscribe'){const b=await readBody(req);let endpoint;try{endpoint=new URL(b.endpoint);}catch{err('푸시 주소 오류');}
   // Only public browser push providers: do not allow arbitrary server-side requests.
   const allowed=endpoint.hostname==='fcm.googleapis.com'||endpoint.hostname==='updates.push.services.mozilla.com'||endpoint.hostname.endsWith('.push.services.mozilla.com')||endpoint.hostname==='web.push.apple.com';
   if(endpoint.protocol!=='https:'||endpoint.username||endpoint.password||endpoint.port||!allowed)err('지원하는 브라우저 푸시 주소가 아닙니다.');
   if(!b.keys||!/^[-_A-Za-z0-9]{80,100}$/.test(b.keys.p256dh)||!/^[-_A-Za-z0-9]{20,30}$/.test(b.keys.auth))err('푸시 암호화 키 오류');
   const existing=one('SELECT owner FROM push_subscriptions WHERE endpoint=?',b.endpoint);if(existing&&existing.owner!==u.name)err('이 기기의 다른 사용자 알림을 먼저 해제하세요.',409);
   run('INSERT INTO push_subscriptions VALUES(?,?,?,NULL) ON CONFLICT(endpoint) DO UPDATE SET payload=excluded.payload,last_error=NULL',b.endpoint,u.name,JSON.stringify({endpoint:b.endpoint,keys:b.keys}));return send(res,200,{ok:true}),true;}
  if(key==='POST /api/push/unsubscribe'){const b=await readBody(req);run('DELETE FROM push_subscriptions WHERE endpoint=? AND owner=?',str(b.endpoint,2000),u.name);return send(res,200,{ok:true}),true;}
  if(key==='POST /api/bridge/pair'){const b=await readBody(req);if(b.consent!==true)err('금융 알림 수집 동의가 필요합니다.');const token=crypto.randomBytes(32).toString('hex'),id=crypto.randomUUID();run('INSERT INTO bridge_devices VALUES(?,?,?,?,?,0)',id,u.name,str(b.name,100)||'Android',crypto.createHash('sha256').update(token).digest('hex'),clock().toISOString());return send(res,200,{id,token,owner:u.name,origin:publicOrigin}),true;}
  if(key==='GET /api/bridge/devices')return send(res,200,{devices:all('SELECT id,name,created,revoked FROM bridge_devices WHERE owner=?',u.name)}),true;
  if(key==='POST /api/bridge/revoke'){const b=await readBody(req);run('UPDATE bridge_devices SET revoked=1 WHERE owner=? AND id=?',u.name,str(b.id,100));return send(res,200,{ok:true}),true;}
  if(key==='GET /api/captures'){const cc=all('SELECT * FROM captures WHERE owner=? AND status=? ORDER BY created DESC LIMIT 200',u.name,'pending').map(c=>({...c,suggestion:JSON.parse(c.suggestion)}));const ee=all('SELECT id,day,amount FROM entries');for(const c of cc)c.duplicateHints={entries:ee.filter(e=>c.suggestion.amount!==null&&e.amount===c.suggestion.amount&&e.day===c.suggestion.day).map(e=>e.id),captures:cc.filter(d=>d.id!==c.id&&c.suggestion.amount!==null&&d.suggestion.amount===c.suggestion.amount&&d.suggestion.day===c.suggestion.day).map(d=>d.id)};return send(res,200,{captures:cc}),true;}
  if(key==='POST /api/captures/dismiss'){const b=await readBody(req);run("UPDATE captures SET status='dismissed' WHERE owner=? AND id=? AND status='pending'",u.name,str(b.id,100));notify('captures');return send(res,200,{ok:true}),true;}
  if(key==='POST /api/captures/link'){const b=await readBody(req);if(!one('SELECT id FROM entries WHERE id=?',str(b.entryId,100)))err('연결할 기존 거래가 없습니다.');const r=run("UPDATE captures SET status='linked',entry_id=? WHERE id=? AND owner=? AND status='pending'",b.entryId,str(b.id,100),u.name);if(!r.changes)err('이미 처리했거나 접근할 수 없는 수집 항목입니다.',409);notify('captures');return send(res,200,{ok:true}),true;}
  return false;
 }
 timer=setInterval(()=>{try{scheduler();for(const p of peers){if(!sessions.has(p.user.id)||p.user.until<=Date.now()){p.res.end();peers.delete(p);}else p.res.write(': heartbeat\n\n');}}catch(e){console.error('결산 점검 실패:',e.message);}},15000);timer.unref();
 function close(){clearInterval(timer);for(const p of peers)p.res.end();peers.clear();}
 return {handle,collect,captureUser,details,addDetails,duplicate,changed,report,scheduler,close,notify,
  requests:{get:(owner,key)=>one('SELECT * FROM request_keys WHERE owner=? AND key=?',owner,key),put:(owner,key,hash,id)=>run('INSERT INTO request_keys VALUES(?,?,?,?)',owner,key,hash,id)},
  capture:(id,owner)=>one('SELECT * FROM captures WHERE id=? AND owner=?',id,owner),
  confirmCapture:(id,entryId)=>run("UPDATE captures SET status='confirmed',entry_id=? WHERE id=? AND status='pending'",entryId,id),
  backup:()=>({details:all('SELECT * FROM entry_details'),captures:all('SELECT * FROM captures'),reports:all('SELECT * FROM daily_reports'),notifications:all('SELECT * FROM notifications')}),
  resetDerived:()=>db.exec('DELETE FROM request_keys; DELETE FROM daily_reports; DELETE FROM notifications;'),
  all,run,one};
}
module.exports={attach,seoul,parseNotification};
