@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "LEDGER_DATA="
set "LEDGER_PORT="
set "LEDGER_ORIGIN="
set "LEDGER_SETUP_TOKEN="
node "%~dp0server.cjs"
pause
