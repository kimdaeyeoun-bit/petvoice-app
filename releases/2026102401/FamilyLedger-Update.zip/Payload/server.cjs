'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const config=fs.existsSync(path.join(__dirname,'config.json'))?JSON.parse(fs.readFileSync(path.join(__dirname,'config.json'),'utf8')):{};
const port=Number(process.env.LEDGER_PORT||3210),local=`http://127.0.0.1:${port}`;
const publicOrigin=process.env.LEDGER_ORIGIN||config.publicOrigin||local;
if(new URL(publicOrigin).origin!==publicOrigin || (publicOrigin!==local&&!publicOrigin.startsWith('https://')))throw Error('공개 주소는 HTTPS origin이어야 합니다.');
const dir=process.env.LEDGER_DATA||path.join(__dirname,'data');fs.mkdirSync(dir,{recursive:true});
const db=new DatabaseSync(path.join(dir,'ledger.sqlite'));db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(name TEXT PRIMARY KEY,salt TEXT NOT NULL,hash TEXT NOT NULL,role TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS accounts(id TEXT PRIMARY KEY,name TEXT NOT NULL,kind TEXT NOT NULL,owner TEXT NOT NULL,opening INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS entries(id TEXT PRIMARY KEY,day TEXT NOT NULL,kind TEXT NOT NULL,src TEXT REFERENCES accounts(id),dst TEXT REFERENCES accounts(id),amount INTEGER NOT NULL CHECK(amount>0),memo TEXT NOT NULL,actor TEXT NOT NULL,created TEXT NOT NULL);`);
const names=['김대연','서정희'],sessions=new Map(),attempts=[];
const all=sql=>db.prepare(sql).all(),run=(sql,...v)=>db.prepare(sql).run(...v);
const initialized=()=>all('SELECT name FROM users').length===2;
const token=process.env.LEDGER_SETUP_TOKEN||crypto.randomBytes(18).toString('hex');
const hash=(p,s)=>crypto.scryptSync(p,s,64).toString('hex');
function err(m,status=400){throw Object.assign(Error(m),{status});}
function str(v,max=500){if(typeof v!=='string'||v.length>max)err('문자열 형식 오류');return v;}
function money(v,positive=false){if(!Number.isSafeInteger(v)||Math.abs(v)>1e12||(positive&&v<=0))err('금액은 1조 원 이하의 원 단위 정수로 입력하세요.');return v;}
function atomic(fn){db.exec('BEGIN IMMEDIATE');try{const v=fn();db.exec('COMMIT');return v;}catch(e){db.exec('ROLLBACK');throw e;}}
function account(a){if(!a||typeof a!=='object')err('계좌 형식 오류');const v={id:str(a.id,100),name:str(a.name,100),kind:str(a.kind,10),owner:str(a.owner,30),opening:money(a.opening)};if(!v.id||!v.name.trim()||!['bank','card','loan','cash'].includes(v.kind)||![...names,'공동'].includes(v.owner))err('계좌 정보 오류');return v;}
function entry(e,lookup){if(!e||typeof e!=='object')err('거래 형식 오류');const v={id:str(e.id,100),day:str(e.day,10),kind:str(e.kind,20),src:e.src===null?null:str(e.src,100),dst:e.dst===null?null:str(e.dst,100),amount:money(e.amount,true),memo:str(e.memo),actor:str(e.actor,30),created:str(e.created,50)};
if(!/^\d{4}-\d{2}-\d{2}$/.test(v.day)||!Number.isFinite(Date.parse(v.day+'T00:00:00Z'))||new Date(v.day+'T00:00:00Z').toISOString().slice(0,10)!==v.day||!v.id||!names.includes(v.actor)||!Number.isFinite(Date.parse(v.created)))err('거래 날짜 또는 등록자 오류');
const s=v.src&&lookup(v.src),d=v.dst&&lookup(v.dst);if((v.src&&!s)||(v.dst&&!d))err('존재하지 않는 계좌');
if(v.kind==='income'){if(s||!d)err('수입은 입금 계좌만 지정하세요.');}
else if(v.kind==='expense'){if(!s||d)err('지출은 출금 계좌만 지정하세요.');}
else if(v.kind==='transfer'){if(!s||!d||v.src===v.dst)err('서로 다른 두 계좌가 필요합니다.');}
else if(v.kind==='payment'){if(!s||!d||s.kind!=='bank'||d.kind!=='card')err('카드 납부는 통장 → 카드입니다.');}
else err('거래 종류 오류');return v;}
function putA(a){run('INSERT INTO accounts VALUES(?,?,?,?,?)',a.id,a.name,a.kind,a.owner,a.opening);}
function putE(e){run('INSERT INTO entries VALUES(?,?,?,?,?,?,?,?,?)',e.id,e.day,e.kind,e.src,e.dst,e.amount,e.memo,e.actor,e.created);}
function state(){const accounts=all('SELECT * FROM accounts ORDER BY name,id'),entries=all('SELECT * FROM entries ORDER BY day,created,id'),balances=Object.fromEntries(accounts.map(a=>[a.id,a.opening]));for(const e of entries){if(e.src)balances[e.src]-=e.amount;if(e.dst)balances[e.dst]+=e.amount;e.after={};for(const id of [e.src,e.dst].filter(Boolean)){if(!Number.isSafeInteger(balances[id]))err('잔액 범위 초과');e.after[id]=balances[id];}}return {accounts,entries,balances};}
function restore(b){if(!b||!['family-ledger-2','family-ledger-3'].includes(b.format)||!Array.isArray(b.accounts)||!Array.isArray(b.entries)||b.accounts.length>1000||b.entries.length>100000)err('백업 형식 오류');const aa=b.accounts.map(account),map=new Map(aa.map(a=>[a.id,a]));if(map.size!==aa.length)err('계좌 중복');const ee=b.entries.map(e=>entry(e,id=>map.get(id)));if(new Set(ee.map(e=>e.id)).size!==ee.length)err('거래 중복');const ids=new Set(ee.map(e=>e.id));const dd=Array.isArray(b.details)?b.details:[];if(dd.some(d=>!ids.has(d.entry_id)||!['김대연','서정희','공동'].includes(d.spent_by))||new Set(dd.map(d=>d.entry_id)).size!==dd.length)err('백업 지출 귀속 정보 오류');
db.prepare('VACUUM INTO ?').run(path.join(dir,'backups','before-restore-'+Date.now()+'-'+crypto.randomUUID()+'.sqlite'));
atomic(()=>{db.exec('DELETE FROM entries;DELETE FROM accounts;');aa.forEach(putA);ee.forEach(putE);for(const d of dd)features.addDetails({id:d.entry_id},d.spent_by);features.resetDerived();features.run("UPDATE captures SET status='pending',entry_id=NULL WHERE entry_id IS NOT NULL AND entry_id NOT IN (SELECT id FROM entries)");state();});features.changed();}
async function body(req){let size=0;const chunks=[];for await(const c of req){size+=c.length;if(size>20*1024*1024)err('20MB 요청 제한',413);chunks.push(c);}try{return JSON.parse(Buffer.concat(chunks).toString()||'{}');}catch{err('JSON 오류');}}
function send(res,status,v,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers});res.end(JSON.stringify(v));}
function auth(req){const id=/(?:^|;\s*)sid=([a-f0-9]+)/.exec(req.headers.cookie||'')?.[1],u=id&&sessions.get(id);if(!u||u.until<Date.now()){if(id)sessions.delete(id);err('로그인이 필요합니다.',401);}return {...u,id};}
const files={'/sms-core.js':['sms-core.js','text/javascript; charset=utf-8'],'/icon-192.png':['icon-192.png','image/png'],'/icon-512.png':['icon-512.png','image/png'],'/':['index.html','text/html; charset=utf-8'],'/app.js':['app.js','text/javascript; charset=utf-8'],'/style.css':['style.css','text/css'],'/manifest.webmanifest':['manifest.webmanifest','application/manifest+json'],'/sw.js':['sw.js','text/javascript'],'/icon.svg':['icon.svg','image/svg+xml']};
const features=require('./features.cjs').attach({db,dir,err,str,atomic,state,entry,putE,readBody:body,send,publicOrigin,local,sessions,auth});
const server=http.createServer(async(req,res)=>{try{
const host=req.headers.host,allowedHosts=new Set([new URL(local).host,new URL(publicOrigin).host]);if(!allowedHosts.has(host))err('허용되지 않는 호스트',403);
const route=new URL(req.url,local).pathname;
if(req.method==='GET'&&files[route]){const [file,mime]=files[route];res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"});return res.end(fs.readFileSync(path.join(__dirname,file)));}
if(!route.startsWith('/api/'))err('찾을 수 없습니다.',404);
if(!['GET','POST'].includes(req.method))err('허용되지 않는 메서드',405);
if(req.method==='POST'&&route==='/api/bridge/collect')return await features.collect(req,res);
if(req.method==='POST'&&(req.headers['x-ledger-request']!=='1'||![local,publicOrigin].includes(req.headers.origin)))err('요청 출처가 잘못되었습니다.',403);
const key=req.method+' '+route;
if(key==='GET /api/status')return send(res,200,{initialized:initialized()});
if(key==='POST /api/setup'){if(initialized())err('이미 설정되었습니다.',409);const b=await body(req);if(b.token!==token)err('서버 창의 설정 코드를 입력하세요.',403);for(const n of names)if(typeof b[n]!=='string'||b[n].length<10||b[n].length>200)err('비밀번호는 각각 10~200자입니다.');atomic(()=>names.forEach((n,i)=>{const salt=crypto.randomBytes(16).toString('hex');run('INSERT INTO users VALUES(?,?,?,?)',n,salt,hash(b[n],salt),i?'member':'admin');}));return send(res,200,{ok:true});}
if(key==='POST /api/login'){while(attempts.length&&attempts[0]<Date.now()-60000)attempts.shift();if(attempts.length>=20)err('1분 후 다시 시도하세요.',429);attempts.push(Date.now());const b=await body(req),n=str(b.name,30),p=str(b.password,200),u=db.prepare('SELECT * FROM users WHERE name=?').get(n),salt=u?.salt||'invalid-salt';const candidate=hash(p,salt);if(!u||!crypto.timingSafeEqual(Buffer.from(candidate,'hex'),Buffer.from(u.hash,'hex')))err('로그인 정보 오류',401);const sid=crypto.randomBytes(32).toString('hex');sessions.set(sid,{name:n,role:u.role,until:Date.now()+8*3600000});for(const [id,s] of sessions)if(s.until<Date.now())sessions.delete(id);return send(res,200,{name:n,role:u.role},{'Set-Cookie':`sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${req.headers.origin.startsWith('https://')?'; Secure':''}`});}
const u=auth(req);
if(await features.handle(key,req,res,u,new URL(req.url,local)))return;
if(key==='POST /api/logout'){sessions.delete(u.id);features.notify();return send(res,200,{ok:true},{'Set-Cookie':'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});}
if(key==='GET /api/state')return send(res,200,{...state(),details:features.details(),user:u.name,role:u.role});
if(key==='POST /api/accounts'){const b=await body(req),a=account({...b,id:crypto.randomUUID()});atomic(()=>{putA(a);state();});features.changed();return send(res,200,{id:a.id});}
if(key==='POST /api/entries'){
 const b=await body(req),e=entry({...b,id:crypto.randomUUID(),actor:u.name,created:new Date().toISOString()},id=>db.prepare('SELECT * FROM accounts WHERE id=?').get(id));
 const owner=db.prepare('SELECT owner FROM accounts WHERE id=?').get(e.src||e.dst)?.owner;
 const spentBy=b.spentBy||(['김대연','서정희'].includes(owner)?owner:u.name);
 if(!['김대연','서정희','공동'].includes(spentBy))err('지출 귀속자 오류');
 const requestId=b.requestId===undefined?null:str(b.requestId,100);if(requestId==='')err('요청 ID 오류');
 const payloadHash=crypto.createHash('sha256').update(JSON.stringify({day:e.day,kind:e.kind,src:e.src,dst:e.dst,amount:e.amount,memo:e.memo,spentBy,captureId:b.captureId||null})).digest('hex');
 if(requestId){const prior=features.requests.get(u.name,requestId);if(prior){if(prior.hash!==payloadHash)err('같은 요청 ID를 다른 거래에 사용할 수 없습니다.',409);return send(res,200,{id:prior.entry_id,reused:true});}}
 const capture=b.captureId?features.capture(str(b.captureId,100),u.name):null;
 if(b.captureId&&(!capture||capture.status!=='pending'))err('이미 처리했거나 접근할 수 없는 수집 항목입니다.',409);
 const duplicates=features.duplicate(e);if(duplicates.length&&b.allowDuplicate!==true)return send(res,409,{error:'중복 가능 거래를 확인하세요.',code:'DUPLICATE_REVIEW',duplicates});
 atomic(()=>{putE(e);features.addDetails(e,spentBy);state();if(requestId)features.requests.put(u.name,requestId,payloadHash,e.id);if(capture)features.confirmCapture(capture.id,e.id);});features.changed();return send(res,200,{id:e.id});}
if(key==='GET /api/backup'){if(u.role!=='admin')err('관리자만 백업할 수 있습니다.',403);const s=state();return send(res,200,{format:'family-ledger-3',details:features.backup().details,exported:new Date().toISOString(),accounts:s.accounts,entries:s.entries.map(({after,...e})=>e)});}
if(key==='POST /api/restore'){if(u.role!=='admin')err('관리자만 복구할 수 있습니다.',403);restore(await body(req));return send(res,200,{ok:true});}
err('찾을 수 없습니다.',404);
}catch(e){if(!res.headersSent)send(res,e.status||400,{error:e.code?'저장 실패: 입력 내용을 확인하세요.':e.message});else res.end();}});
server.listen(port,'127.0.0.1',()=>{features.scheduler();console.log(`가계부: ${publicOrigin}\n로컬 관리: ${local}`);if(!initialized())console.log(`최초 설정 코드: ${token}`);});
function close(){features.close();server.close(()=>{db.close();process.exit(0);});}process.on('SIGINT',close);process.on('SIGTERM',close);
