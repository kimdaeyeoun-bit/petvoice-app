'use strict';
// Read-only backup validation. Never runs application tests against the user's DB.
const {DatabaseSync}=require('node:sqlite');
const p=process.argv[2];if(!p)throw Error('DB path required');
const db=new DatabaseSync(p,{readOnly:true});try{
 if(db.prepare('PRAGMA quick_check').get().quick_check!=='ok')throw Error('SQLite integrity check failed');
 const required={users:['name','salt','hash','role'],accounts:['id','name','kind','owner','opening'],entries:['id','day','kind','src','dst','amount','memo','actor','created']};
 for(const [table,columns]of Object.entries(required)){const present=db.prepare(`PRAGMA table_info(${table})`).all().map(c=>c.name);if(!columns.every(c=>present.includes(c)))throw Error('Unsupported existing schema: '+table);}
 const version=db.prepare('PRAGMA user_version').get().user_version;if(version>2)throw Error('Newer DB schema is not supported by this updater');
 const counts=Object.fromEntries(Object.keys(required).map(t=>[t,db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n]));
 console.log(JSON.stringify({integrity:'ok',schemaVersion:version,counts}));
}finally{db.close();}
